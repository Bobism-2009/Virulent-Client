Virulent Client — Install
=========================

Version: 1.10.6
Minecraft: 26.1.2
Java: 25+
Fabric Loader: 0.19.3+


What's in this zip
------------------
- virulent-client-1.10.6.jar   (Virulent)
- fabric-api-0.155.2+26.1.2.jar (Fabric API for 26.1.2)
- README.txt                  (this file)


Install
-------
1) Install Java 25
   https://adoptium.net/

2) Install Fabric for Minecraft 26.1.2
   https://fabricmc.net/use/installer/
   - Minecraft version: 26.1.2
   - Install, then select the Fabric 26.1.2 profile in the launcher

3) Open your mods folder
   Windows: Win+R → %appdata%\.minecraft\mods

4) Copy BOTH jars from this zip into mods:
   - fabric-api-0.155.2+26.1.2.jar
   - virulent-client-1.10.6.jar

5) Launch the Fabric 26.1.2 profile (not vanilla).

6) In game, press Right Shift to open the Click GUI.


Checklist
---------
[ ] Java 25+
[ ] Minecraft 26.1.2
[ ] Fabric Loader profile for 26.1.2
[ ] Both jars in .minecraft\mods
[ ] Launched Fabric profile
[ ] Right Shift opens Click GUI


Common issues
-------------
- Wrong Minecraft version → this build is for 26.1.2 only
- Missing Fabric API → put fabric-api-0.155.2+26.1.2.jar in mods
- Wrong Java → use Java 25+
- Launched vanilla → select the Fabric 26.1.2 profile
